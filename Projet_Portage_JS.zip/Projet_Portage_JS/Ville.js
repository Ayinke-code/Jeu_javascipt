export class Ville {
    constructor(nom, etat) {
      this.nom = nom;
      this.etat = etat;
    }
  
    getNom() {
      return this.nom;
    }
  }