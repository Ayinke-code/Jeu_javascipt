export class Etat {
    constructor(nom, contour) {
      this.nom = nom;
      this.contour = contour;
    }
  }