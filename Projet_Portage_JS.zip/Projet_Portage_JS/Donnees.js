export const Donnees = {
    ETATS: [
      ["Californie", "Contour1"],
      ["Texas", "Contour2"]
    ],
    VILLES: [
      ["Los Angeles", "Californie"],
      ["Houston", "Texas"]
    ],
    ROUTES: [
      ["Los Angeles", "Houston", "rouge"]
    ]
  };